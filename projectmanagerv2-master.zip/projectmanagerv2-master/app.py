from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
from helpers import login_required, password_check

# Configure application
app = Flask(__name__)

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///main.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    if not session.get("name"):
        return render_template("login.html")
    projects = db.execute(
        "SELECT name, code FROM projects WHERE code IN (SELECT projcode FROM access WHERE user = ?)", session["name"])
    return render_template("home.html", projects=projects)
    
    
@app.route("/project", methods=["POST"])
@login_required
def project():
    code = request.form.get("code")
    name = db.execute("SELECT name FROM projects WHERE code = ?", code)[0]["name"]
    messages = db.execute("SELECT * FROM ?", code)
    projects = db.execute(
        "SELECT name, creator, code FROM projects WHERE code IN (SELECT projcode FROM access WHERE user = ?)", session["name"])
    return render_template("message_templ.html", messages=messages, code=code, name=name, projects=projects) 


@app.route("/send", methods=["POST"])
@login_required
def send():
    code = request.form.get("code")
    message = request.form.get("message")
    name = db.execute("SELECT name FROM projects WHERE code = ?", code)[0]["name"]
    db.execute("INSERT INTO ? (sender, message) VALUES (?, ?)", code, session["name"], message)
    messages = db.execute("SELECT * FROM ?", code)
    projects = db.execute(
        "SELECT name, creator, code FROM projects WHERE code IN (SELECT projcode FROM access WHERE user = ?)", session["name"])
    return render_template("message_templ.html", messages=messages, code=code, name=name, projects=projects)
   
   
@app.route("/create", methods=["POST"])
@login_required
def create():
    name = request.form.get("name")
    code = request.form.get("code")
    if not name or not code:
        flash("Name and Code are necessary", "info")
        return redirect("/")
    else:
        try:
            db.execute("INSERT INTO projects (name, code, creator) VALUES (?, ?, ?)", name, code, session["name"])
        except:
            flash("Access code already taken", "info")
            return redirect("/")
        db.execute("INSERT INTO access (user, projcode) VALUES (?, ?)", session["name"], code)
        db.execute("CREATE TABLE ? (sender TEXT NOT NULL, message TEXT NOT NULL)", code)
        flash("Project successfully created", "success")
        return redirect("/")


@app.route("/join", methods=["POST"])
@login_required
def join():
    # Check if proj exists
    code = request.form.get("code")
    proj_check = db.execute("SELECT * FROM projects WHERE code = ?", code)
    if len(proj_check) == 0:
        flash("Incorrect code", "info")
        return redirect("/")
    db.execute("INSERT INTO access (user, projcode) VALUES (?, ?)", session["name"], code)
    flash("You have successfully joined the project", "success")
    return redirect("/")

  
@app.route("/account", methods=["GET"])
@login_required
def account():
    projects = db.execute(
        "SELECT name, creator, code FROM projects WHERE code IN (SELECT projcode FROM access WHERE user = ?)", session["name"])
    return render_template("account.html", projects=projects)


@app.route("/leave", methods=["POST"])
@login_required
def leave():
    code = request.form.get("code")
    db.execute("DELETE FROM access WHERE user = ? AND projcode = ?", session["name"], code)
    flash("You have successfully left the project", "success")
    return redirect("/")


@app.route("/delete", methods=["POST"])
@login_required
def delete():
    code = request.form.get("code")
    db.execute("DELETE FROM access WHERE user = ? AND projcode = ?", session["name"], code)
    db.execute("DELETE FROM projects WHERE code = ?", code)
    db.execute("DROP TABLE ?", code)
    flash("Project successfully deleted", "success")
    return redirect("/")


@app.route("/login", methods=["GET", "POST"])
def login():

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            flash("Must provide username", "info")
            return render_template("login.html")

        # Ensure password was submitted
        elif not request.form.get("password"):
            flash("Must provide password", "info")
            return render_template("login.html")
        session["name"] = request.form.get("username")
        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", session["name"])

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            flash("Invalid username and / or password", "info")
            return render_template("login.html")
        
        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/register", methods=["GET", "POST"])
def register():
    # Clear session and check for method
    session.clear()
    """Register user"""
    if request.method == "GET":
        return render_template("register.html")
    
    username_r = request.form.get("username")
    password1 = request.form.get("password")
    password2 = request.form.get("confirmation")

    if not (password_check(password1)):
        flash(" Password must have at least one number, one uppercase and one lowercase character at least one special symbol and must be between 6 to 20 characters long")
        return render_template("register.html")

    if not username_r or not password1 or not password2:
        flash("All fields are required")
        return render_template("register.html")
    hashed_password = generate_password_hash(password1)

    try:
        db.execute("INSERT INTO users (username, hash) VALUES (?, ?)", username_r, hashed_password)
        flash("Account successfully created", "success")
        return render_template("login.html")
    except:
        flash("Username already exists", "info")
        return render_template("register.html")

